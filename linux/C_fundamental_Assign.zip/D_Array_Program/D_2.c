#include<stdio.h>
void main()
{int numarray[5]={5,20,5,16,20};
int i,greatest;
for(i=0;i<5;i++){
	if (numarray[] < numarray[i])
		greatest=numarray[i+1];
}
printf("Greatest number in array is %d",greatest);
}
