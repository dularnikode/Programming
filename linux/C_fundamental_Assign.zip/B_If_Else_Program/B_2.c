#include <stdio.h>
void main()
{
int num1;
printf("#check weather even or odd\n");
printf("Enter the number : ");
scanf("%d",&num1);
if ((num1%2) == 0 )
	printf("Number is even.\n");
else
	printf("Number is odd.\n");
}
