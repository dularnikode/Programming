#include <stdio.h>
void main()
{int i;
char alpha;
printf("#printing from 1 to 100\n");
for (i=1;i<101;i++)
	printf("%d\n",i);
printf("\n#printing from A to Z\n");
for (alpha=65;alpha<=90;alpha++)
	printf("%c\n",alpha);
printf("#printing form 500 to 400");
for (i=500;i>=400;i--)
	printf("%d\n",i);

}
