#include <stdio.h>
void main()
{
float pi,radius;
pi=3.1428;
radius=5.6;
printf("Circumference of circle is %f\n",2*pi*radius);
printf("Area of circle is %f\n",pi*radius*radius);
}
