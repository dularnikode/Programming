#include <stdio.h>
void main()
{
int area,a,b;
printf("Enter the length of rectangle : ");
scanf("%d",&a);
printf("Enter the width of rectangle : ");
scanf("%d",&b);
area =a*b;
printf("Area of rectangle is %d\n",area);
}
