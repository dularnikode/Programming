#include <stdio.h>
void main()
{
int a,b;
printf("Enter two numbers for addition : ");
scanf("%d %d",&a,&b);
printf("Additon of  two numbers %d and %d is %d \n",a,b,a+b);
}
